<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, inicial-scale=1.0">
    <title>Sitio Web Responsivo de Hamburguesas</title>
    <!-- El favicon es el pequeño ícono que aparece en la pestaña del navegador y en otras ubicaciones, como marcadores o pestañas abiertas -->
    <link rel="shortcut icon" href="./img/favicon.png" type="image/x-icon">
    <!-- Boxicons es una biblioteca de iconos vectoriales que proporciona una amplia variedad de iconos listos para usar en una página web -->
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="Css/styles.css">
</head>

<body>
    <!-- Encabezado de la página -->
    <header class="header" id="header">
        <nav class="nav">
            <!-- Logo de la navegación -->
            <a class="nav__logo" href="#"><img class="nav__logo-img" src="./img/logo-burger.svg" alt="logo"><span>Hamburguesas</span></a>
            <!-- Menú de navegación -->
            <div class="nav__menu" id="nav-menu">
                <ul class="nav__list" id="nav-list">
                    <!-- Elementos del menú -->
                    <li class="nav__item"><a class="nav__link active-link" href="#home">Inicio</a></li>
                    <li class="nav__item"><a class="nav__link" href="#recipe">Receta</a></li>
                    <li class="nav__item"><a class="nav__link" href="#popular">Populares</a></li>
                    <li class="nav__item"><a class="nav__link" href="#delivery">Entrega</a></li>
                    <li class="nav__item"><a class="nav__link" href="#contact">Contacto</a></li>
                </ul>
            </div>
            
            <!-- Botón del menú hamburguesa -->
            <div class="nav__btns">
                <i class='bx bx-grid-alt' id="hamburger"></i>
            </div>
        </nav>
    </header>

    <!-- Sección de inicio -->
    <section class="home" id="home">
        <div class="home__container">
            <div class="home__data">
                <!-- Título principal -->
                <h1 class="home__title">Ama Cada Hamburguesa</h1>
                <!-- Descripción principal -->
                <p class="home__description">Bienvenidos a la página de hamburguesas, donde podrás disfrutar de las mejores delicias.</p>  
            </div>
            <!-- Imagen principal -->
            <div class="home__img">
                <img class="home-burger" src="./img/home-burger.png" alt="hamburguesa">
                <!-- Imágenes adicionales (ingredientes) -->
                <img class="home-dish abosolute" src="./img/home-dish.png">
                <img class="home-potato1 abosolute ingredient" src="./img/home-potato.png">
                <img class="home-potato2 abosolute ingredient" src="./img/home-potato.png">
                <img class="home-tomato abosolute ingredient" src="./img/home-tomato.png">
                <img class="home-lettuce abosolute ingredient" src="./img/home-lettuce.png">
            </div>
        </div>
    </section>

    <!-- Sección de receta -->
    <section class="recipe" id="recipe">
        <!-- Título de la sección -->
        <h2 class="section__title">Nuestra Receta Secreta</h2>
        <div class="recipe__container">
            <div class="recipe__img">
                <!-- Imagen principal de la receta -->
                <img src="./img/recipe-burger.png">
            </div>
            <div class="recipe__description">

                <?php
                // Array de recetas con imagen, título y descripción
                $recipes = [
                    ["image" => "recipe-bread.png", "title" => "Pan", "description" => "Pan recién horneado, crujiente y delicioso."],
                    ["image" => "recipe-cheese.png", "title" => "Queso", "description" => "Queso cremoso y derretido para un sabor irresistible."],
                    ["image" => "recipe-meat.png", "title" => "Carne", "description" => "100% carne de res."],
                    ["image" => "recipe-vegetable.png", "title" => "Vegetales", "description" => "Vegetales frescos y orgánicos llenos de nutrientes."],
                    ["image" => "recipe-sauces.png", "title" => "Salsas", "description" => "Salsas caseras y sabrosas para complementar tu experiencia culinaria."]
                ];

                // Recorremos cada receta y la mostramos en la página
                foreach ($recipes as $recipe) { // Itera sobre cada elemento en el array $recipes
/**
 * La estructura foreach ($recipes as $recipe) toma cada elemento del areglo $recipes uno a uno y lo asigna temporalmente a la variable $recipe 
 * En cada iteración del bucle, el valor del elemento actual del array se asigna a la variable $recipe (es para mostrar cada uno de los elementos del arreglo).
 */                    
                    echo '<div class="recipe__box"> <!-- Abre un contenedor para la receta -->
                            <div class="image"> <!-- Abre un contenedor para la imagen -->
                                <img src="./img/' . $recipe["image"] . '"> <!-- Muestra la imagen de la receta -->
                            </div> <!-- Cierra el contenedor de la imagen -->
                            <div class="conten"> <!-- Abre un contenedor para el contenido de la receta -->
                                <h5>' . $recipe["title"] . '</h5> <!-- Muestra el título de la receta -->
                                <p>' . $recipe["description"] . '</p> <!-- Muestra la descripción de la receta -->
                            </div> <!-- Cierra el contenedor del contenido -->
                        </div>'; //-- Cierra el contenedor de la receta 
                }
?>

            </div>
        </div>
    </section>

    <!-- ScrollReveal es una biblioteca JavaScript que permite animar elementos cuando se hacen visibles durante el desplazamiento hacia abajo en la página -->
    <script src="https://unpkg.com/scrollreveal"></script>

            <!--Funciona como el "llamado" que hacemos al CSS-->
    <script src="js/script.js"></script>
</body>

</html>
