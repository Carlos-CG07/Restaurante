// Detecta el evento de scroll en el documento
document.addEventListener("scroll", (e) => {
  // Verifica si el desplazamiento vertical es igual a 0 (en la parte superior de la página)
  if (window.scrollY === 0) {
    // Remueve la clase "header-efecto" del elemento con clase ".header"
    document.querySelector(".header").classList.remove("header-efecto");
  } else {
    // Si no está en la parte superior, agrega la clase "header-efecto" al elemento con clase ".header"
    document.querySelector(".header").classList.add("header-efecto");
  }
});

// Obtiene el elemento con id "hamburger"
const hamburger = document.getElementById("hamburger");

// Añade un evento de click al elemento "hamburger"
hamburger.addEventListener("click", (e) => {
  // Alterna la clase "mostrar-list" en el elemento con id "nav-list"
  document.getElementById("nav-list").classList.toggle("mostrar-list");
  // Alterna la clase "bxs-x-square" en el elemento "hamburger"
  hamburger.classList.toggle("bxs-x-square");
});

// Configuración de ScrollReveal
const sr = ScrollReveal({
  origin: "left",      // Desde donde aparece el elemento (izquierda)
  distance: "50px",    // Distancia desde donde aparece el elemento
  duration: 2000,      // Duración de la animación
  delay: 300,          // Retraso antes de la animación
  reset: true,         // Si se reinicia la animación al hacer scroll nuevamente
});

// Aplica la animación a elementos con clase "home__data"
sr.reveal(".home__data");

// Aplica la animación a elementos con clase "home-dish"
sr.reveal(".home-dish", {
  delay: 500,         // Retraso específico para este elemento
  distance: "100px",  // Distancia específica desde donde aparece
  origin: "bottom",   // Desde donde aparece (parte inferior)
});

// Aplica la animación a elementos con clase "home-burger"
sr.reveal(".home-burger", {
  origin: "right",    // Desde donde aparece (derecha)
  delay: 1200,        // Retraso específico para este elemento
  distance: "200px",  // Distancia específica desde donde aparece
  duration: 1500,     // Duración específica de la animación
});

// Aplica la animación a elementos con clase "ingredient"
sr.reveal(".ingredient", {
  origin: "top",      // Desde donde aparece (parte superior)
  delay: 1600,        // Retraso específico para este elemento
  interval: 200,      // Intervalo entre la animación de cada elemento
  distance: "500px",  // Distancia específica desde donde aparece
});

// Aplica la animación a elementos con clase "recipe__img"
sr.reveal(".recipe__img", {
  origin: "left",     // Desde donde aparece (izquierda)
});

// Aplica la animación a elementos con clase "recipe__description"
sr.reveal(".recipe__description", {
  origin: "right",    // Desde donde aparece (derecha)
});
